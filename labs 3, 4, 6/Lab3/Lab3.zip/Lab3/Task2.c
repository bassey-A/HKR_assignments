#include <stdio.h>

int main(){
    //input the number to calculate
    double num;
    // variables
    double sum = 1.0;
    double top = 1.0;
    int count = 1;

    printf("Enter the value of x: ");
    scanf("%lf", &num);

    //display the result header
    printf("term    values\n");

    do {
        //display next row
        printf("%2d  \t %.7lf\n", count, sum);

        //calculate the value of the numerator
        top = top*num;

        //divide the numerator by the factorial of count
        top = top/(count * 1.0);

        //and the result to the sum
        sum += top;

        //increment the counter
        count++;




    }while (0.0000001 < top);

    return 0;
}