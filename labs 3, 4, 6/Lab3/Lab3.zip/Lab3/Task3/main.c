#include <stdio.h>
#include "task3Functions.h"

int main() {

    int stat = statesFromUser();
    dispBinary(stat);
    if ((stat | 0) == 0){
        printf("All systems are normal\n");
    }
    if ((stat & (1<<4)) != 0){
        printf("Fuel level low!!!\n");
    }
    if (((stat & (1<<5)) != 0) && ((stat & (1<<2)) != 0)){
        printf("Check temperature!!!\n");
    }
    if ((stat & (1<<1)) || (stat & (1<<0)) != 0){
        printf("Brake System failure!!!\n");
    }
    return 0;
}
