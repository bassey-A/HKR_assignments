//
// Created by basee on 2021-04-01.
//

#ifndef UNTITLED10_TASK3FUNCTIONS_H
#define UNTITLED10_TASK3FUNCTIONS_H

void dispBinary(int num);
int getEntry();
int statesFromUser();
int binaryArray[8];
char console[8][30] = {"Enter brake pad condition:", "Enter brake fluid level:",
                       "Enter engine temperature:", "Enter engine oil level:", "Enter fuel level:",
                       "Enter outside weather:", "Enter exhaust gas quality:", "Enter tyre pressure:"};

void dispBinary(int num){       //display the stat as an 8-bit binary
    printf("\nstat in 8 bit binary:\t");
    for (int i = 0; i < 8; i++){
        binaryArray[i] = num % 2;
        num = num / 2;
    }
    for (int i = 7; i >= 0; i--){
        printf("%d", binaryArray[i]);
    }
    printf("\n\n");
}

int getEntry() {        //read entries from the keyboard
    int a;
    do {
        scanf("%d", &a);
        if ((a != 0) && (a != 1)){
            printf("Invalid entry\nEnter 0 or 1!\n");
        }
    }
    while ((a != 0) && (a != 1));
    return a;
}

int statesFromUser(){       //input the conditions of the various components (we dont have sensors to read from)
    int a = 0;

    for (int i = 0; i < 8; i++){
        printf("%s\n", console[i]);
        printf("0 = normal, 1 = requires attention\n");
        if (getEntry() == 1){a |= (1<<i);}
    }

    return a;
}
#endif //UNTITLED10_TASK3FUNCTIONS_H
