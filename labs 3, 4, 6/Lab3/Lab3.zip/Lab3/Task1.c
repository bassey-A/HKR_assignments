#include <stdio.h>

int main() {
    int num;
    int col;
    int row;
    char x[2] = "X";
    char bar[2] = "|";
    printf("Enter the size of the table:     ");
    scanf("%d", &num);

    //create and label the array
    int multi[num + 1][num + 1];
    for (int i = 0; i <= num; i++){
        multi[0][i] = i;
        multi[i][0] = i;
    }

    //fill the values in the array
    for (int i = 1; i <= num; i++) {
        for (int j = 1; j <= num; j++) {
            multi[i][j] = i * j;
        }
    }

    //display the output
    printf("\n");
    printf("%2s", x);
    printf("%s", bar);
    for (int i = 1; i <= num; i++){
        printf("%5d", i);
        }
    printf("\n");
    for (int i = 0; i < num; i++)
    {printf("-----");}
    printf("---");
    printf("\n");

    for (row = 1; row <= num; row++) {
        printf("%2d", row);
        printf("%s", bar);

        for (col = 1; col <= num; col++) {
            printf("%5d", multi[row][col]);
            if (col == num) { printf("\n"); }
        }
    }

    return 0;
}
