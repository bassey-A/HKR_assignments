//
// Created by Ebeten Alaga on 2021-05-15.
//

#ifndef LAB6TASK1_LAB6TASK1_H
#define LAB6TASK1_LAB6TASK1_H

//Libraries
#include <stdio.h>
#include <string.h>
#include <stdlib.h>


//Type Definitions
typedef enum {Female, Male} sex;
typedef enum {low, normal, high} level;
typedef enum {preschool, preschoolClass, comprehensiveSchool} school;

//Definitions
#define yellowFever 0
#define hepatitis 1
#define malaria 2
#define birdFlue 3
#define polio 4

//Constants
#define Sodium_Low_Bound 135
#define Sodium_High_Bound 145
#define Potassium_Low_Bound 2.5
#define Potassium_High_Bound 3.5
#define Adult_Age 16

//Structs
typedef struct address{
    char city[20];
    char streetName[20];
    int streetNumber;
    int postCode;
}address;

typedef struct sodium{
    int sodiumLevel;
    level level;
}sodium;

typedef struct potassium{
    float potassiumLevel;
    level level;
}potassium;

typedef struct healthRecord{
    char firstName[15];
    char lastName[15];
    int birthYear;
    int birthMonth;
    int birthDay;
    sex gender;
    float height;
    float weight;
    float BMI;
    address address;
    int vaccineHistory;
    sodium sodium;
    potassium potassium;
    school education;
    struct healthRecord *next;
}healthRecord;

//Variables
healthRecord records[10];
int count;
healthRecord temp;

//Function Prototypes
float calculateBMI(float weight, float height);
void getPatientProfile(healthRecord *patient);
void savePatientProfile(healthRecord *record);
void showPatientProfile(healthRecord *patient);
void readPatientProfile();
void setVaccineStatus(int *add, int vaccine);
school setEducation();
void menu();
void levelPrinter(int i);
void vaccinePrinter(int vac);
void sortRecords();
void swap(healthRecord *one, healthRecord *two);
void displayTen();
void exit(int x);

#endif //LAB6TASK1_LAB6TASK1_H
