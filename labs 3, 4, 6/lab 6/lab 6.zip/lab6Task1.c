//
// Created by Ebeten Alaga on 2021-05-15.
//
#include "lab6Task1.h"
char var;


float calculateBMI(float weight, float height){
    /*this function calculates the BMI*/
    return (weight /(height * height));
}

void getPatientProfile(healthRecord *patient){
    /*this function captures the patient's health record using the keyboard*/
    patient->next = NULL;
    patient->BMI = 0;
    printf("Enter your first name here: \n");
    gets(patient->firstName);
    gets(patient->firstName);
    printf("Enter your last name here:  \n");
    gets((*patient).lastName);
    printf("Enter birthday. Use format YYYY,MM,DD   \n");
    scanf("%d,%d,%d", &patient->birthYear, &patient->birthMonth, &patient->birthDay);
    printf("Sex: \nEnter F for female or M for male   \n");
    do{
        scanf("%c", &var);
        if (var == 'm' || var == 'M'){
            patient->gender = Male;
        }else if (var == 'f' || var == 'F') {
            patient->gender = Female;
        }
    }while (var != 'm' && var != 'M' && var != 'f' && var != 'F');
    printf("Enter height in meters: \n");
    scanf("%f", &patient->height);
    printf("Enter weight in kilograms:   \n");
    scanf("%f", &patient->weight);
    patient->BMI = calculateBMI(patient->weight, patient->height);
    printf("Enter your city:   \n");
    gets(patient->address.city);
    gets(patient->address.city);
    printf("Enter your street: \n");
    gets(patient->address.streetName);
    printf("Enter your house number:    \n");
    scanf("%d", &patient->address.streetNumber);
    printf("Enter your postcode:    \n");
    scanf("%d", &patient->address.postCode);
    printf("Have you had a yellow fever vaccine? \nY for yes or N for no.\n");
    setVaccineStatus(&patient->vaccineHistory, yellowFever);
    printf("Have you had a hepatitis vaccine? \nY for yes or N for no.\n");
    setVaccineStatus(&patient->vaccineHistory, hepatitis);
    printf("Have you had a malaria vaccine? \nY for yes or N for no.\n");
    setVaccineStatus(&patient->vaccineHistory, malaria);
    printf("Have you had a bird flue vaccine? \nY for yes or N for no.\n");
    setVaccineStatus(&patient->vaccineHistory, birdFlue);
    printf("Have you had a polio vaccine? \nY for yes or N for no.\n");
    setVaccineStatus(&patient->vaccineHistory, polio);

    if ((2021 - patient->birthYear) < Adult_Age){
        patient->education = setEducation();
        patient->potassium.potassiumLevel = '\0';
        patient->potassium.level = '\0';
    }else{
        patient->education = '\0';
        if (patient->gender == Female){
            patient->sodium.sodiumLevel = '\0';
            patient->sodium.level = '\0';
            printf("What is your Potassium level?\n");
            scanf("%f", &patient->potassium.potassiumLevel);
            if (patient->potassium.potassiumLevel < Potassium_Low_Bound){
                patient->potassium.level = low;
            }else if (patient->potassium.potassiumLevel > Potassium_High_Bound){
                patient->potassium.level = high;
            }else {
                patient->potassium.level = normal;
            }
        }else{
            patient->potassium.potassiumLevel = '\0';
            patient->potassium.level = '\0';
            printf("What is your Sodium level?\n");
            scanf("%d", &patient->sodium.sodiumLevel);
            if (patient->sodium.sodiumLevel < Sodium_Low_Bound){
                patient->sodium.level = low;
            }else if (patient->sodium.sodiumLevel > Sodium_High_Bound){
                patient->sodium.level = high;
            }else {
                patient->sodium.level = normal;
            }
        }
    }
    savePatientProfile(&temp);
    showPatientProfile(&temp);
    menu();
}

void savePatientProfile(healthRecord *record){
    /*this function save the health record that has just been captured to a text file*/
    FILE *file;
    file = fopen("Health_Records.txt", "ab");
    if (file == NULL){
        printf("Unable to open file");
    }else{
        printf("%s %s's health records saved.\n", record->firstName, record->lastName);
    }
    fwrite(&temp, sizeof(healthRecord), 1, file);
    fclose(file);
}

void showPatientProfile(healthRecord *patient){
    /*this function displays the health record of one patient on the screen*/
    printf("\n\n%s %s's Health Record\n", patient->firstName, patient->lastName);
    printf("First Name:         %s\n", patient->firstName);
    printf("Last Name:          %s\n", patient->lastName);
    printf("Address:            %d %s, %d, %s\n", patient->address.streetNumber,
           patient->address.streetName, patient->address.postCode, patient->address.city);
    printf("Birthday:           %d-%d-%d\n", patient->birthYear, patient->birthMonth, patient->birthDay);
    printf("Gender:             ");
    if (patient->gender == 0){
        printf("Female\n");
    } else {
        printf("Male\n");
    }
    printf("Height:             %.2f\n", patient->height);
    printf("Weight:             %.2f\n", patient->weight);
    printf("BMI:                %.2f\n", patient->BMI);

    if ((2021 - patient->birthYear) < Adult_Age){
        if (patient->education == 0){
            printf("School:             Preschool\n");
        }else if (patient->education == 1){
            printf("School:             Preschool Class\n");
        } else if (patient->education == 2){
            printf("School:             Comprehensive School\n");
        }
    }else{
        if (patient->gender == 0){
            printf("Potassium Level:    %.2f\t", patient->potassium.potassiumLevel);
            levelPrinter(patient->potassium.level);
        }else{
            printf("Sodium Level:       %d\t\t", patient->sodium.sodiumLevel);
            levelPrinter(patient->sodium.level);
        }
    }
    vaccinePrinter(patient->vaccineHistory);
    //menu();
}

void readPatientProfile(){
    /* this function reads the saved health records from a text file*/

    FILE *file;
    file = fopen("Health_Records.txt", "rb");
    if (file == NULL){ printf("Unable to locate source file!");}
    while(fread(&temp, sizeof(healthRecord), 1, file)){
        count++;
    }
    rewind(file);

    fread(&records, sizeof(healthRecord), count, file);
    fclose(file);
}

void setVaccineStatus(int *vac, int pos){
    /*this function takes a pointer to the vaccine history and an integer corresponding to a particular vaccine
     * as arguments records if the vaccine has been taken using bitwise operations*/
    char temp;
    do {
        scanf("%c", &temp);
    } while (temp != 'n' && temp != 'N' && temp != 'y' && temp != 'Y');
    if (temp == 'n' || temp =='N');
    else (*vac) |= (1<<pos);
}

school setEducation() {
    /*this function is used to set the school a child attends*/
    int entry;
    do{
        printf("Which school do you attend?\n"
               "1.  Preschool\n"
               "2.  Preschool Class\n"
               "3.  Comprehensive School\n");

        scanf("%d", &entry);
    } while (entry != 1 && entry != 2 && entry != 3);

    switch (entry) {
        case 1: return preschool;
        case 2: return preschoolClass;
        case 3: return comprehensiveSchool;
    }
}

void menu(){
    /*this function displays an on-screen menu*/
    char choice[3];
    int x;
    do {
        printf("\n\nMetro Health Information Management System\n\n");
        printf("What would you like to do?\n"
               "1.  Enter new patient information\n"
               "2.  View saved patients' information\n"
               "3.  Exit\n");
        scanf("%s", choice);
        x = atoi(choice);
    }while ((x != 1) && (x != 2) && (x != 3));
    switch (x) {
        case 1: {
            healthRecord empty = {0};
            temp = empty;
            getPatientProfile(&temp);
            break;
        }
        case 2: {
            readPatientProfile();
            sortRecords();
            displayTen();
            break;
        }
        case 3: {
            exit(0);
        }
    }
}

void levelPrinter(int i){
    /*this function takes an integer as argument and displays a message corresponding to its value*/
    if (i == 0){
        printf("Low\n");
    }else if (i == 1){
        printf("Normal\n");
    }else if (i == 2){
        printf("High\n");
    }
}

void exit(int x);       //quits the program

void vaccinePrinter(int vac){
    /*this function displays the vaccine history. It takes an integer as argument*/
    printf("\nVACCINE HISTORY\n");

    printf("Yellow Fever:   \t");
    if (vac & (1<<yellowFever)){
        printf("Taken\n");
    }else if (!(vac & (1<<yellowFever))){
        printf("Not taken\n");
    }

    printf("Hepatitis:   \t\t");
    if (vac & (1<<hepatitis)){
        printf("Taken\n");
    }else if (!(vac & (1<<hepatitis))){
        printf("Not taken\n");
    }

    printf("Malaria:   \t\t");
    if (vac & (1<<malaria)){
        printf("Taken\n");
    }else if (!(vac & (1<<malaria))){
        printf("Not taken\n");
    }

    printf("Bird Flu:   \t\t");
    if (vac & (1<<birdFlue)){
        printf("Taken\n");
    }else if (!(vac & (1<<birdFlue))){
        printf("Not taken\n");
    }

    printf("Polio:   \t\t");
    if (vac & (1<<polio)){
        printf("Taken\n");
    }else if (!(vac & (1<<polio))){
        printf("Not taken\n");
    }
}

void sortRecords(){
    /*this function bubble sorts health records in an array*/
    int x = count;
    while(x > 0) {
        for (int i = 0; i < count; i++) {
            if (((records+i)->BMI) > ((records+i+1)->BMI)){swap((records+i), (records+i+1));}
        }
        x--;
    }
}

void swap(healthRecord *one, healthRecord *two){
    /*this function swaps the positions of two health records passed as arguments*/
    temp = *(one);
    *(one) = *(two);
    *(two) = temp;
}

void displayTen(){
    /*this function displays the records read from the text file*/
    char enter;
    for (int i = 1; i <= count; i++){


            printf("\nPress ENTER to continue\n");
            scanf("%c", &enter);
            if ((int)enter == 10) {
                showPatientProfile((records + i));
            }
    }
    menu();
}
