#include "lab6Task1.h"

int main() {

    menu();

    return 0;
}
